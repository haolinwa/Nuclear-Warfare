
class gameEngine():
    def __init__ (self):
        self.gameBoard = [['bR','bN','bB','bQ','bK','bB','bN','bR'],
                        ['bp','bp','bp','bp','bp','bp','bp','bp'],
                        ['','','','','','','',''],
                        ['','','','','','','',''],
                        ['','','','','','','',''],
                        ['','','','','','','',''],
                        ['wp','wp','wp','wp','wp','wp','wp','wp'],
                        ['wR','wN','wB','wQ','wK','wB','wN','wR']]
                        
    def isValidMove(self,oldMTuple,newMTuple):
        self.oldY = oldMTuple[0]
        self.oldX = oldMTuple[1]
        self.newY = newMTuple[0]
        self.newX = newMTuple[1]
        self.selectedPiece = self.gameBoard[self.oldX][self.oldY]
        self.destination = self.gameBoard[self.newX][self.newY]
        #if selected empty, move invalid
        if self.selectedPiece == '':
            return False
        #checks if destination piece color is the same 
        #if same then move is invalid
        if self.selectedPiece[0] == self.destination[0]:
            return False
        #Pawns
        if self.selectedPiece == 'bp':
            return False
        #King
        if self.selectedPiece == 'bK' or self.selectedPiece == 'wK':
            if abs(self.newX-self.oldX) == 1 and abs(self.newY-self.newY) == 1:
                return True
            return False
        #Rooks
        if self.selectedPiece == 'bR' or self.selectedPiece == 'wR':
            if self.oldX == self.newX or self.oldY == self.newY:
                for x in range(self.oldX+1,self.newX):
                    if self.gameBoard[x,self.oldY] != '':
                        return False
                for y in range(self.oldY+1,self.newY):
                    if self.gameBoard[self.oldX,y] != '':
                        return False
                return True
            return False
        #Knight
        if self.selectedPiece == 'bR' or self.selectedPiece == 'wR':
            return True
        
    def movePiece(self,oldMTuple,newMTuple):
        self.oldY = oldMTuple[0]
        self.oldX = oldMTuple[1]
        self.newY = newMTuple[0]
        self.newX = newMTuple[1]
        #if destination empty, simply move
        if self.gameBoard[self.newX][self.newY] == '':
            self.gameBoard[self.newX][self.newY] = self.gameBoard[self.oldX][self.oldY]
            self.gameBoard[self.oldX][self.oldY] = ''
            print(self.gameBoard)
        #if target occupied, boom
        else:
            self.explosion(self.newX,self.newY)
            self.gameBoard[self.oldX][self.oldY] = ''


    def explosion(self,x,y):
        #explodes all pieces in 3x3 squares except pawns
        self.gameBoard[self.newX][self.newY] = ''
        if self.gameBoard[x-1][y] != 'bp' or 'wp':
            self.gameBoard[x-1][y] = ''
        if self.gameBoard[x+1][y] != 'bp' or 'wp':
            self.gameBoard[x+1][y] = ''
        if self.gameBoard[x][y-1] != 'bp' or 'wp':
            self.gameBoard[x][y-1] = ''
        if self.gameBoard[x][y+1] != 'bp' or 'wp':
            self.gameBoard[x][y+1] = ''
        if self.gameBoard[x+1][y+1] != 'bp' or 'wp':
            self.gameBoard[x+1][y+1] = ''
        if self.gameBoard[x-1][y-1] != 'bp' or 'wp':
            self.gameBoard[x-1][y-1] = ''
        if self.gameBoard[x+1][y-1] != 'bp' or 'wp':
            self.gameBoard[x+1][y-1] = ''
        if self.gameBoard[x-1][y+1] != 'bp' or 'wp':
            self.gameBoard[x-1][y+1] = ''

