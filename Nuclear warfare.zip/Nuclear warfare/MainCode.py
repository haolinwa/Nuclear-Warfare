#GUI not fully completed
#The pieces are able to move in the internal gameboard list
#pieces are able to move internally
from pygame import *
from LogicEngine import *

engine = gameEngine()
bWidth = bHeight = 720
squareSize = bWidth//8
Images = {}

def loadImages():
    pieces = ['wR','wN','wB','wQ','wK','wp','bR','bN','bB','bQ','bK','bp']
    for i in pieces:
        Images[i] = transform.scale(image.load('images/'+i+'.png'),(squareSize,squareSize))

def createBoard(wnd):
    chessBoard = image.load('images/chessBoard.png')
    chessBoard = transform.scale(chessBoard, (bWidth,bHeight))
    wnd.blit(chessBoard,(0,0))

def createPieces(wnd,gameBoard):
    for row in range(8):
        for column in range(8):
            piece = gameBoard[row][column]
            if piece != '':
                wnd.blit(Images[piece],(column*90,row*90))

def putOnWnd(wnd):
    createBoard(wnd)
    createPieces(wnd,engine.gameBoard)
    display.update()

#main function
def main():
    init()
    wnd = display.set_mode((bWidth,bHeight))
    display.set_caption("Game")
    
    fps = 50
    clock = time.Clock()
    run = True
    selectedSq = ()
    alreadySelect = False
    loadImages()
    while run:
        clock.tick(fps)
        for e in event.get():
            if e.type == QUIT:
                run = False
            #mouse selection
            elif e.type == MOUSEBUTTONDOWN:
                pos = mouse.get_pos()
                selectedSqX = pos[0]//squareSize
                selectedSqY = pos[1]//squareSize
                #Deselects if same square
                if selectedSq == (selectedSqX,selectedSqY):
                    selectedSq = ()
                    alreadySelect = False
                else:
                    if alreadySelect == False:
                        selectedSq = (selectedSqX,selectedSqY)
                        alreadySelect = True
                        print(selectedSq)
                    #if already selected a square selects new square
                    else:
                        #Temporary testing case code(isValidMove Engine is not yet fully functional)
                        if True:
                            print("this is second click")
                        #if engine.isValidMove(selectedSq,(selectedSqX,selectedSqY)):
                            newCoordinate = (selectedSqX,selectedSqY)
                            print(newCoordinate)
                            engine.movePiece(selectedSq,newCoordinate)
                            putOnWnd(wnd)
                        selectedSq = ()
                        alreadySelect = False
        putOnWnd(wnd)

if __name__ == '__main__':
    main()


